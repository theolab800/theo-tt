# AutoLock Elite — Site Premium Serrurier Automobile

## Structure du projet

```
autolock-elite/
├── public/
│   └── index.html      ← Le site complet
├── vercel.json         ← Configuration Vercel
└── README.md
```

## Déploiement sur Vercel

### Option 1 — Via l'interface Vercel (recommandé)

1. Créez un compte sur [vercel.com](https://vercel.com) si ce n'est pas fait
2. Uploadez ce dossier sur GitHub (voir ci-dessous)
3. Connectez votre repo GitHub à Vercel
4. Vercel détecte automatiquement la config et déploie

### Option 2 — Via Vercel CLI (terminal)

```bash
# Installer Vercel CLI
npm install -g vercel

# Dans le dossier du projet
cd autolock-elite
vercel

# Suivre les instructions interactives
# → Set up and deploy? Yes
# → Which scope? (votre compte)
# → Link to existing project? No
# → Project name: autolock-elite
# → In which directory is your code? ./
# → Want to override settings? No
```

### Uploader sur GitHub d'abord

```bash
git init
git add .
git commit -m "Initial deploy — AutoLock Elite"
gh repo create autolock-elite --public --push --source=.
```

## Personnalisation avant mise en ligne

Ouvrez `public/index.html` et remplacez :

| À remplacer | Par votre vraie valeur |
|---|---|
| `06 00 00 00 00` | Votre numéro de téléphone |
| `+33600000000` | Votre numéro au format international |
| `contact@autolock-elite.fr` | Votre email |
| `autolock-elite.fr` | Votre vrai domaine |
| `AutoLock Elite` | Votre nom d'entreprise (si différent) |

## Domaine personnalisé

Dans Vercel > Settings > Domains :
- Ajoutez votre domaine (ex: `votre-site.fr`)
- Configurez les DNS chez votre registrar :
  - Type A → `76.76.21.21`
  - CNAME `www` → `cname.vercel-dns.com`

## SEO

Le site inclut déjà :
- Balises meta title/description optimisées
- Schema.org LocalBusiness
- Balises Open Graph
- Structure H1/H2 correcte
- Canonical URL → à mettre à jour avec votre vrai domaine
